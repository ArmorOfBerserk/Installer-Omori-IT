const defaultConfig = { gomori: true, _basilFiles: [] };

module.exports = { defaultConfig };
