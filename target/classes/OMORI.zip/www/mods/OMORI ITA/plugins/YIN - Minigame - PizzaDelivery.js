//-----------------------------------------------------------------------------
// OMORI Minigame - Pizza Delivery
//-----------------------------------------------------------------------------

Game_Interpreter.prototype.initPizzaDelivery = function () {
    ImageManager.loadPicture("PIZZA-Background");
    ImageManager.loadAtlas("MN_PizzaItems");

    $gameSystem._chosenHouses = [];
    $gameSystem._checkedHouses = [];

    var _pizzaHouse1 = this.generateHouse(1);
    var _pizzaHouse2 = this.generateHouse(2);
    var _pizzaHouse3 = this.generateHouse(3);

    this._pizzaHouse1 = _pizzaHouse1;
    this._pizzaHouse2 = _pizzaHouse2;
    this._pizzaHouse3 = _pizzaHouse3;

    // this.checkImages();
}

Game_Interpreter.prototype.checkImages = function () {
    var houseText = this.houseHints();
    for (var i = 1; i < 37; i++) {
        // console.log(houseText[i]);
        for (var j = 0; j < houseText[i].length; j++) {
            // console.log(houseText[i][j]);
            text = houseText[i][j];
            text = text.split(" ");
            for (var word = 0; word < text.length; word++) {
                ImageManager.loadPicture('PIZZA-' + text[word]);
            }
        }
    }
}

Game_Interpreter.prototype.houseHints = function () {
    return {
        1: ["Cans In Yard", "PickupTruck Red", "Rug Green", "Cans by Garbage", "Roof Run Brown", "Window Boarded", "Brick Front", "No Fence", "Roots In Yard", "Plants On Driveway", "Garbage Lined In Front"],

        2: ["PickupTruck Green Dark", "Rug Purple", "Chimney In Roof Yellow", "Door Yellow With Windows", "Windows In Door"],

        3: ["Rug White", "Door Pink Dark", "Ball Tether In Yard", "Roof Pink", "One Window Pink Front", "Flowers Purple by Window"],

        4: ["Rug Gray", "Door Orange", "Cones Front Of Driveway", "Roof Blue Light", "Ladder by Tree"],
        //-----------------------------------------
        5: ["Car Gray", "Rock Large In Yard", "Flowers by Rock Large", "Rug Purple", "Roof Orange", "Brick Front", "No Cans"],

        6: ["Door White", "Roof Blue Dark With Chimney", "Front Beat", "Easel In Yard", "Plants In Yard"],

        7: ["PickupTruck Red", "Door Yellow Light With Windows", "Boxes In Side Yard", "Flowers Purple by Window Yellow", "Rug Purple Dark", "No Cans", "Roof Red", "No Fence"],

        8: ["Roof Purple With A Chimney", "Yard Messy", "Rug Brown", "No Fence", "Ladder by Door", "Hydrant Front", "Door Red Dark"],
        //-----------------------------------------
        9: ["Roof Brown Light", "Door Pink", "PickupTruck Gray", "No Fence"],

        10: ["Roof Yellow", "Tires In Yard", "Door White No Windows", "Table Picnic On Side", "Grill In Yard"],

        11: ["Roof Blue", "Door Brown Light", "Rug Brown", "Dog", "Roots In Yard"],

        12: ["Roof Green Light", "Toys In Yard", "Cans by Fence White", "Rug White", "One Window Green", "Rock Large In Yard", "Hydrant Front"],
        //-----------------------------------------======================================================================================================================================================================================
        13: ["Light by Driveway", "Rug Green Dark", "PickupTruck Blue", " Fence Brown With Bushes", "Hydrant Front", "Chinmney Purple In A Roof Green Dark"],

        14: ["Roof Brown", "Roots And Flowers In Yard", "Tree In Entrance", "Rug Yellow Dark", "Door Red Dark", "Door Garage White"],

        15: ["Roof Blue With The Chimney Blue", "Brick White Front", "PickupTruck Green", "Garbage On Side Left", "Hoops In Yard", "Ball Tether", "Bushes by Door Garage Brown Light"],

        16: ["Car Pink In Driveway", "Roof Brown With Chimney Green Dark", "Door Yellow With Windows", "Flowers Yellow In Bushes"],
        //-----------------------------------------
        17: ["Car White", "Door Garage Pink Light", "Rug Pink Light", "Door White With Windows", "Patch Dirt by Fence", "Roof Gray Light", "Flowers In Yard", "Boxes by Door Garage"],

        18: ["Roof Brown Dark", "Door Garage No Windows", "Fence Beat", "PickupTruck Green", "Garbage Front", "Flowers Yellow In Bushes", "Trees In Yard", "Couch In Garbage"],

        19: ["Roof Red", "Garbage Messy On Side Left", "Rug Blue", "Door Gray", "Rock Lined Driveway", "Bottles And Cans In Yard", "Tree by Door", "No Windows In Door Garage", "Chimney Red"],

        20: ["Roof Brown Light", "Door Orange", "Garbage On Side Of Driveway", "Car Gray", "Chimney Brown", "Flowers Bushes Lined Driveway"],
        //-----------------------------------------
        21: ["Roof Purple", "Chimney Purple", "Door Pink", "Door Garage Red Dark", "Hydrant Front", "Rug Blue Dark", "Car Pink", "Birdhouse In Yard", "Mailbox Front", "Boxes Flowers In Yard", "Grill On Side Right", "Planks Wood by Trees"],

        22: ["Door Brown Dark", "Roof Green Dark", "Brick White Front", "Plants by Door", "Mulch On Side Of Yard", "Garbage by Fence", "Dog", "Chimney Purple", "Hoops"],

        23: ["Roof Yellow", "Table Work On Side", "Tools In Yard", "Rug Yellow", "PickupTruck Gray", "Door Garage White With Windows", "Tires In Yard"],

        24: ["PickupTruck Red", "Roof BLue", "Cones Front", "Door Yellow With Windows", "Flamingo", "Birdhouse", "Chimney Blue"],
        //-----------------------------------------======================================================================================================================================================================================
        25: ["Roof Purple", "Rug White", "Flamingo And Trees On Driveway", "Fence Brown On Side Left", "Chimney Gray", "One Window Pink", "Grill by Table Picnic"],

        26: ["Roof Brown Light", "Door Brown", "Hoops by Fence Brown", "Rug Purple", "Two Cans Black", "Toys In Yard", "Brick Brown Light Front", "Cones Front"],

        27: ["Roof Brown Dark", "Sign Front", "Roots In Yard", "Flowers Red by Window Yellow"],

        28: ["Flowers Lined Path", "Garbage On Side Left And Right", "Two Cans Green On Right", "Roof White", "Door White", "Hydrant Front", "Chimney White"],
        //-----------------------------------------
        29: ["Roof Yellow", "Door Red Dark", "Rug Brown", "Garbage In Front", "Tires In Yard", "Ladder by Door", "PickupTruck Gray", "PickupTruck Blue", "Planks Wood On Side"],

        30: ["Fence White", "Car Pink", "Flowers Lined Driveway", "Roof Brown Light", "Grill On Side Left", "Door Pink Dark"],

        31: ["Roof Brown Dark", "Swing", "Ball Tether", "Flowers In Yard", "Garbage On Patch Dirt", "Small Patch Dirt", "Toys Front"],

        32: ["Roof Red", "Rug Gray", "Door Orange", "Roots In Yard", "Two Cans Green", "Front Beat", "Hydrant Front", "Ladder On Planks Wood", "Chimney Gray"],
        //-----------------------------------------
        33: ["Roof Gray", "Brick Front", "Rug Purple", "Ladder by Door", "Two Cans", "Bottles by Garbage", "Dog", "Planks Wood In Yard", "No Fence", "PickupTruck Gray Front"],

        34: ["Car White Front", "Mailbox Front", "Cans by Garbage Front", "Roof Blue Light", "Trees by Entrance", "Door Red Light", "Hoops", "Rug Green Light"],

        35: ["Car Yellow Front", "Flowers Red by Window", "Flowers by Path Small", "Mulch In Yard", "Roof Blue", "Rug Blue Dark", "Trees In Front Of Fence White"],

        36: ["Hydrant Front", "No Fence", "Flowers Purple by Window Pink", "Garbage On Side Right by Toys", "Door Pink", "Roof White", "Car Gray", "Toys Car In Yard"],
    }
}

Game_Interpreter.prototype.generateHouse = function (neighborhood) {
    var neighborhoodHouses = {
        1: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        2: [13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24],
        3: [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36]
    }

    var houseHintsPt1 = this.houseHints();
    var chosenHouse = $gameSystem.randomizeArray(neighborhoodHouses[neighborhood])[0];

    while (!chosenHouse || $gameSystem._chosenHouses.contains(chosenHouse)) {
        chosenHouse = $gameSystem.randomizeArray(neighborhoodHouses[neighborhood])[0];
    }
    // console.log(chosenHouse);


    $gameSystem._chosenHouses.push(chosenHouse);
    var wordPool = houseHintsPt1[chosenHouse];

    $gameSystem.randomizeArray(wordPool);
    var description1 = wordPool[0];
    wordPool.splice(0, 1);

    $gameSystem.randomizeArray(wordPool);
    var description2 = wordPool[0];
    wordPool.splice(0, 1);

    $gameSystem.pizza = [description1, description2];

    var partPool = [
        "This Pizza Goes Down The Street To The House With The ",
        "Please Take This Pizza To House With The ",
        "Look For The House That Has The ",
        "This Pizza Goes To House With The ",
        "Take The Pizza To House That Has The ",
        "Find The House With The ",
        "Can Find The House With The ",
        "Take This Pizza To House With The ", 
        "Take This Pizza Down The Street To House With The ",
        "Please Find The House With The ",
        "This Pizza Goes To House That Has The ",
        "Can Find The House That Has The "
    ]

    $gameSystem.randomizeArray(partPool);
    var part = partPool[0];

    var text = part + $gameSystem.pizza[0] + " And the " + $gameSystem.pizza[1];
    if (text.contains("The No")) {
        text = text.replace("The No", "No");
    }

    return text;
}

Game_Interpreter.prototype.showPizzaNote = function (text) {
    AudioManager.playSe({name: 'GEN_mess_paper', volume: 100, pitch: 100})
    if (text === 0) text = this._pizzaHouse1;
    if (text === 1) text = this._pizzaHouse2;
    if (text === 2) text = this._pizzaHouse3;

    var note = SceneManager._scene._pizzaNote = new Window_PizzaDeliveryNote(text);
    SceneManager._scene.addChild(note);
}

Game_Interpreter.prototype.correctHouse = function (houseID) {
    if (houseID === $gameSystem._chosenHouses[$gameVariables.value(817)]) return true;
    return false;
}

Game_Interpreter.prototype.checkedHouseAlready = function () {
    if (!$gameSystem._checkedHouses.contains($gameVariables.value(822))) {
        $gameSystem._checkedHouses.push($gameVariables.value(822));
        return false;
    }
    return true;
}

Game_Interpreter.prototype.checkingCurrentHouse = function (houseID) {
    $gameVariables.setValue(822, houseID);
}

//=============================================================================
//
//=============================================================================
Game_System.prototype.randomizeArray = function (array) {
    if (!array) return;
    var curElement = array.length;
    var temp;
    var randomizedLoc;
    while (0 !== curElement) {
        randomizedLoc = Math.floor(Math.random() * curElement);
        curElement -= 1;
        temp = array[curElement];
        array[curElement] = array[randomizedLoc];
        array[randomizedLoc] = temp;
    };
    return array;
}

//=============================================================================
//
//=============================================================================
function Window_PizzaDeliveryNote() {
    this.initialize.apply(this, arguments);
}

Window_PizzaDeliveryNote.prototype = Object.create(Window_Base.prototype);
Window_PizzaDeliveryNote.prototype.constructor = Window_PizzaDeliveryNote;

Window_PizzaDeliveryNote.prototype.initialize = function (text) {
    var x = (Graphics.boxWidth - this.windowWidth()) / 2;
    var y = (Graphics.boxHeight - this.windowHeight()) / 3;
    Window_Base.prototype.initialize.call(this, x, y, this.windowWidth(), this.windowHeight());
    this.opacity = 0;
    this.refresh(text);
};

Window_PizzaDeliveryNote.prototype.standardPadding = function () {
    return 0;
}

Window_PizzaDeliveryNote.prototype.refresh = function (text) {
    this.contents.clear();
    this.visible = true;
    var bitmap = ImageManager.loadPicture('PIZZA-Background');
    this.contents.blt(bitmap, 0, 0, bitmap.width, bitmap.height, 0, 0);
    text = text.split(" ");
    // console.log(text);
    var nextX = 24;
    var nextY = 32;
    for (var i = 0; i < text.length; i++) {
        var bitmap = ImageManager.loadPicture('PIZZA-' + text[i]);
        if (nextX + bitmap.width > 580) {
            nextX = 24;
            nextY += 64;
        }
        this.contents.blt(bitmap, 0, 0, bitmap.width, bitmap.height, nextX, nextY);
        nextX = nextX + bitmap.width + 20;
    }
}

Window_PizzaDeliveryNote.prototype.update = function () {
    Window_Base.prototype.update.call(this);
    if (Input.isTriggered("ok")) {
        this.closeNote();
    }
}

Window_PizzaDeliveryNote.prototype.windowWidth = function () {
    return Graphics.boxWidth - 20;
};

Window_PizzaDeliveryNote.prototype.windowHeight = function () {
    return Graphics.boxHeight - 40;
};

Window_PizzaDeliveryNote.prototype.closeNote = function () {
    this.close();
    this.visible = false;
    SceneManager._scene.removeChild(SceneManager._scene._pizzaNote);
}

var yin_updateCallMenu = Scene_Map.prototype.updateCallMenu;
Scene_Map.prototype.updateCallMenu = function () {
    if ($gamePlayer.canMove() && this.isMenuCalled() && $gameSwitches.value(818)) {
        if ((SceneManager._scene._pizzaNote && !SceneManager._scene._pizzaNote.visible)) {
            SceneManager._scene._pizzaNote.closeNote();
            $gameMap._interpreter.showPizzaNote($gameVariables.value(817));
            return;
        } else if (!SceneManager._scene._pizzaNote) {
            $gameMap._interpreter.showPizzaNote($gameVariables.value(817));
        }
    } else {
        yin_updateCallMenu.apply(this);
    }
}

var yin_Pizza_moveByInput = Game_Player.prototype.moveByInput;
Game_Player.prototype.moveByInput = function () {
    if (SceneManager._scene._pizzaNote && SceneManager._scene._pizzaNote.visible) return;
    yin_Pizza_moveByInput.call(this);
};

Game_Character.prototype.getRandomNPCGraphic = function () {
    this._opacity = 0;
    this._characterName = $gameSystem.randomizeArray(["FA_PizzaPeople_01", "FA_PizzaPeople_02"])[0];
    this._characterIndex = $gameSystem.randomizeArray([0, 1, 2, 3, 4, 5, 6, 7])[0];
    var frame = 1;
    this._direction = 2;
    this._pattern = this._originalPattern = frame % 3;
    this._priorityType = 2;
}
